import React from 'react'
import AllRoutes from '@routes/AllRoutes';
const App:React.FC = () => {
  return (
    <div>
    <AllRoutes/>
    </div>
  )
}

export default App;
