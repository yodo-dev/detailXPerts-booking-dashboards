export interface OverviewCardProps {
    img:string;
    monthlyRevenue?:string;
    totalFranchises?:string;
    totalCustomers?:string;
    totalDetailers?:string;
    title:string;
    averageIncrese:string;
    averageTitle:string;
    index: number;
}