export interface CommonInputsProps {
    showImg?:boolean;
    inputClass?:string;
    placeholder?:string;
    showEdit?:boolean;
}